let handler = async m => m.reply(`
╭─「 Donasi • Pulsa 」
│ • Tri [089513228004]
│ • Gopay [085727229628]
╰────
`.trim()) // Tambah sendiri kalo mau
handler.help = ['donasi']
handler.tags = ['info']
handler.command = /^dona(te|si)$/i

module.exports = handler
